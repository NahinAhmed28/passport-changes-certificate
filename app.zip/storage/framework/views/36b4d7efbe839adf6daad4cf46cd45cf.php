<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passport Change Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Passport Change Records</h2>
        <a href="<?php echo e(route('passport.create')); ?>" class="btn btn-primary">+ Add New</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>#</th>
            <th>Serial</th>
            <th>Date</th>
            <th>Old Passport No</th>
            <th>New Passport No</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($record->serial); ?></td>
                <td><?php echo e($record->date); ?></td>
                <td><?php echo e($record->old_passport_number); ?></td>
                <td><?php echo e($record->new_passport_number); ?></td>
                <td>
                    <a href="<?php echo e(route('passport.show', $record->id)); ?>" class="btn btn-sm btn-info">Details</a>
                    <a href="<?php echo e(route('passport.edit', $record->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">No records found.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
<?php /**PATH D:\personal\passport-changes\resources\views/passport-list.blade.php ENDPATH**/ ?>