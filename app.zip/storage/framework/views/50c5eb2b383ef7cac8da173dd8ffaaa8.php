<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: "Times New Roman", Times, serif;
            font-size: 12pt;
            line-height: 1.5;
        }
    </style>
</head>
<body>
<p>
    <?php
        $text = "This is to certify that ";

        // Name
        $text .= $passportChange->new_name
                 ? "Mr. {$passportChange->new_name} "
                 : "this person ";

        // New passport
        if ($passportChange->new_passport_number) {
            $text .= "bearing Bangladesh passport no. {$passportChange->new_passport_number}";
            if ($passportChange->new_passport_issue_date) {
                $text .= " issued on " . \Carbon\Carbon::parse($passportChange->new_passport_issue_date)->format('d F Y');
            }
            $text .= ", ";
        }

        // Old passport
        if ($passportChange->old_passport_number) {
            $text .= "in his old passport no. {$passportChange->old_passport_number}, ";
        }

        // Collect incorrect/correct fields
        $wrong = [];
        $correct = [];

        if ($passportChange->name_changed) {
            $wrong[] = "name as {$passportChange->old_name}";
            $correct[] = "name as {$passportChange->new_name}";
        }
        if ($passportChange->father_changed) {
            $wrong[] = "father's name as {$passportChange->old_father_name}";
            $correct[] = "father's name as {$passportChange->new_father_name}";
        }
        if ($passportChange->mother_changed) {
            $wrong[] = "mother's name as {$passportChange->old_mother_name}";
            $correct[] = "mother's name as {$passportChange->new_mother_name}";
        }
        if ($passportChange->dob_changed) {
            $wrong[] = "date of birth as " . \Carbon\Carbon::parse($passportChange->old_dob)->format('d F Y');
            $correct[] = "date of birth as " . \Carbon\Carbon::parse($passportChange->new_dob)->format('d F Y');
        }

        if (count($wrong) > 0) {
            $text .= "the following information was incorrect: " . implode(', ', $wrong)
                   . "; the correct information is: " . implode(', ', $correct) . ". ";
        }

        // NID / BRC
        if ($passportChange->nid && $passportChange->brc) {
            $text .= "This information is verified as mentioned in his National Identity Card (NID) and Birth Certificate (BRC) issued by the competent authority in Bangladesh.";
        } elseif ($passportChange->nid) {
            $text .= "This information is verified as mentioned in his National Identity Card (NID) issued by the competent authority in Bangladesh.";
        } elseif ($passportChange->brc) {
            $text .= "This information is verified as mentioned in his Birth Certificate (BRC) issued by the competent authority in Bangladesh.";
        }
    ?>

    <?php echo e($text); ?>

</p>
</body>
</html>
<?php /**PATH D:\personal\passport-changes\resources\views/summery-print.blade.php ENDPATH**/ ?>